import React, { useState } from 'react'

const TIPS = [
  'Por favor ser puntuales. La recepcion comienza en punto.',
  'Queremos que disfrutes esta fiesta al maximo, por eso decidimos que sea un evento solo para adultos.',
  'Llevar un abrigo ligero para disfrutar de los jardines por la noche.',
  'Olvidarse de todo y a disfrutar!!!',
]

export default function TipsModal() {
  const [open, setOpen] = useState(false)

  const s = {
    btn: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      width: '100%',
      padding: '14px 20px',
      background: 'white',
      border: '1.5px solid var(--blue-mist)',
      borderRadius: 14,
      fontFamily: "'Lora', serif",
      fontSize: 15,
      color: 'var(--blue-deep)',
      cursor: 'pointer',
    },
    overlay: {
      position: 'fixed', inset: 0,
      background: 'rgba(44,48,56,0.5)',
      backdropFilter: 'blur(4px)',
      zIndex: 1000,
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      padding: '0 0 20px',
    },
    modal: {
      background: 'white',
      borderRadius: '24px 24px 16px 16px',
      width: '100%',
      maxWidth: 430,
      padding: '0 0 24px',
      animation: 'fadeUp 0.3s ease',
      boxShadow: '0 -4px 40px rgba(61,110,138,0.15)',
    },
    iconWrap: {
      display: 'flex',
      justifyContent: 'center',
      marginTop: -28,
      marginBottom: 16,
    },
    icon: {
      width: 56, height: 56,
      background: '#F0F4F7',
      borderRadius: '50%',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      border: '3px solid white',
      boxShadow: '0 2px 12px rgba(61,110,138,0.15)',
      fontSize: 24,
    },
    closeBtn: {
      position: 'absolute',
      top: 16, right: 20,
      background: '#F0F4F7',
      border: 'none',
      borderRadius: '50%',
      width: 32, height: 32,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer',
      fontSize: 14,
      color: 'var(--text-mid)',
    },
    inner: { padding: '0 24px', position: 'relative' },
    title: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 28,
      color: 'var(--text)',
      textAlign: 'center',
      marginBottom: 20,
    },
    divider: {
      width: '100%',
      height: 1,
      background: 'linear-gradient(90deg, transparent, var(--gold), transparent)',
      marginBottom: 20,
    },
    tip: {
      display: 'flex',
      gap: 12,
      marginBottom: 14,
      alignItems: 'flex-start',
    },
    dot: {
      width: 7, height: 7,
      borderRadius: '50%',
      background: 'var(--blue-mid)',
      flexShrink: 0,
      marginTop: 7,
    },
    tipText: {
      fontFamily: "'Lora', serif",
      fontSize: 14,
      color: 'var(--text-mid)',
      lineHeight: 1.6,
    },
  }

  return (
    <>
      <button style={s.btn} onClick={() => setOpen(true)}>
        <span>📋</span>
        <span>Tips y Notas</span>
      </button>

      {open && (
        <div style={s.overlay} onClick={() => setOpen(false)}>
          <div style={s.modal} onClick={e => e.stopPropagation()}>
            <div style={s.inner}>
              <div style={s.iconWrap}>
                <div style={s.icon}>📋</div>
              </div>
              <button style={s.closeBtn} onClick={() => setOpen(false)}>✕</button>
              <h2 style={s.title}>Tips y Notas</h2>
              <div style={s.divider} />
              {TIPS.map((tip, i) => (
                <div key={i} style={s.tip}>
                  <div style={s.dot} />
                  <p style={s.tipText}>{tip}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  )
}
