import React from 'react'

// Gato 1 — Siames blanco/crema, sentado (esquina sup izq)
function CatSiames({ style }) {
  return (
    <svg viewBox="0 0 110 130" style={style} xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="52" cy="95" rx="38" ry="28" fill="#F0E8D8"/>
      <circle cx="52" cy="52" r="26" fill="#F0E8D8"/>
      <polygon points="32,38 24,18 42,30" fill="#E8D5C0"/>
      <polygon points="72,38 80,18 62,30" fill="#E8D5C0"/>
      <polygon points="34,38 26,22 40,32" fill="#D4A0A0" opacity="0.7"/>
      <polygon points="70,38 78,22 64,32" fill="#D4A0A0" opacity="0.7"/>
      <ellipse cx="43" cy="50" rx="5" ry="6" fill="#3D6E8A"/>
      <ellipse cx="61" cy="50" rx="5" ry="6" fill="#3D6E8A"/>
      <ellipse cx="43" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <ellipse cx="61" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <circle cx="44" cy="48" r="1.2" fill="white"/>
      <circle cx="62" cy="48" r="1.2" fill="white"/>
      <path d="M49,58 L52,61 L55,58" fill="#D4A0A0"/>
      <line x1="52" y1="61" x2="52" y2="64" stroke="#D4A0A0" strokeWidth="1"/>
      <line x1="35" y1="58" x2="22" y2="55" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <line x1="35" y1="61" x2="22" y2="61" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <line x1="35" y1="64" x2="22" y2="67" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <line x1="69" y1="58" x2="82" y2="55" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <line x1="69" y1="61" x2="82" y2="61" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <line x1="69" y1="64" x2="82" y2="67" stroke="#C8B8A8" strokeWidth="1" opacity="0.6"/>
      <path d="M85,100 Q105,80 100,58" stroke="#E8D5C0" strokeWidth="7" fill="none" strokeLinecap="round"/>
      <ellipse cx="35" cy="118" rx="11" ry="6" fill="#E8D5C0"/>
      <ellipse cx="58" cy="120" rx="11" ry="6" fill="#E8D5C0"/>
    </svg>
  )
}

// Gato 2 — Tabby atigrado con lazo, sentado (esquina sup der)
function CatTabby({ style }) {
  return (
    <svg viewBox="0 0 110 130" style={style} xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="52" cy="95" rx="38" ry="28" fill="#C4956A"/>
      <path d="M20,90 Q52,80 84,90 Q84,118 52,123 Q20,118 20,90Z" fill="#C4956A"/>
      <line x1="30" y1="88" x2="74" y2="88" stroke="#9B7040" strokeWidth="2.5" opacity="0.5"/>
      <line x1="28" y1="96" x2="76" y2="96" stroke="#9B7040" strokeWidth="2.5" opacity="0.5"/>
      <line x1="30" y1="104" x2="74" y2="104" stroke="#9B7040" strokeWidth="2.5" opacity="0.5"/>
      <circle cx="52" cy="52" r="26" fill="#C4956A"/>
      <line x1="40" y1="30" x2="38" y2="42" stroke="#9B7040" strokeWidth="2" opacity="0.6"/>
      <line x1="52" y1="28" x2="52" y2="40" stroke="#9B7040" strokeWidth="2" opacity="0.6"/>
      <line x1="64" y1="30" x2="66" y2="42" stroke="#9B7040" strokeWidth="2" opacity="0.6"/>
      <polygon points="32,38 24,18 42,30" fill="#B8845E"/>
      <polygon points="72,38 80,18 62,30" fill="#B8845E"/>
      <polygon points="34,38 26,22 40,32" fill="#D4A0A0" opacity="0.7"/>
      <polygon points="70,38 78,22 64,32" fill="#D4A0A0" opacity="0.7"/>
      <ellipse cx="43" cy="50" rx="5" ry="6" fill="#C9A060"/>
      <ellipse cx="61" cy="50" rx="5" ry="6" fill="#C9A060"/>
      <ellipse cx="43" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <ellipse cx="61" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <circle cx="44" cy="48" r="1.2" fill="white"/>
      <circle cx="62" cy="48" r="1.2" fill="white"/>
      <path d="M49,58 L52,61 L55,58" fill="#D4A0A0"/>
      <line x1="35" y1="58" x2="22" y2="55" stroke="#9B7040" strokeWidth="1" opacity="0.5"/>
      <line x1="35" y1="61" x2="22" y2="61" stroke="#9B7040" strokeWidth="1" opacity="0.5"/>
      <line x1="69" y1="58" x2="82" y2="55" stroke="#9B7040" strokeWidth="1" opacity="0.5"/>
      <line x1="69" y1="61" x2="82" y2="61" stroke="#9B7040" strokeWidth="1" opacity="0.5"/>
      {/* Lazo */}
      <path d="M44,72 Q52,68 60,72 Q52,76 44,72Z" fill="#C9A060"/>
      <ellipse cx="48" cy="72" rx="5" ry="3.5" fill="#E8C870" opacity="0.8"/>
      <ellipse cx="56" cy="72" rx="5" ry="3.5" fill="#E8C870" opacity="0.8"/>
      <circle cx="52" cy="72" r="3" fill="#C9A060"/>
      <path d="M85,100 Q105,80 100,58" stroke="#B8845E" strokeWidth="7" fill="none" strokeLinecap="round"/>
      <ellipse cx="35" cy="118" rx="11" ry="6" fill="#B8845E"/>
      <ellipse cx="58" cy="120" rx="11" ry="6" fill="#B8845E"/>
    </svg>
  )
}

// Gato 3 — Gris durmiendo (esquina inf izq)
function CatGris({ style }) {
  return (
    <svg viewBox="0 0 140 80" style={style} xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="70" cy="48" rx="60" ry="22" fill="#9BB0C0"/>
      <ellipse cx="70" cy="48" rx="60" ry="22" fill="#9BB0C0"/>
      <ellipse cx="28" cy="35" rx="22" ry="20" fill="#9BB0C0"/>
      <polygon points="14,24 10,10 22,20" fill="#8AA0B0"/>
      <polygon points="30,22 28,8 38,18" fill="#8AA0B0"/>
      <polygon points="15,24 11,13 21,21" fill="#C8A0A8" opacity="0.6"/>
      <polygon points="30,22 29,11 37,19" fill="#C8A0A8" opacity="0.6"/>
      <path d="M16,35 Q20,34 24,35" stroke="#708090" strokeWidth="1.5" fill="none"/>
      <ellipse cx="22" cy="34" rx="3" ry="1.5" fill="#708090" opacity="0.4"/>
      <ellipse cx="34" cy="33" rx="3" ry="1.5" fill="#708090" opacity="0.4"/>
      <line x1="8" y1="36" x2="2" y2="34" stroke="#8090A0" strokeWidth="1" opacity="0.5"/>
      <line x1="8" y1="38" x2="2" y2="38" stroke="#8090A0" strokeWidth="1" opacity="0.5"/>
      <line x1="42" y1="36" x2="48" y2="34" stroke="#8090A0" strokeWidth="1" opacity="0.5"/>
      <path d="M124,42 Q138,30 130,18" stroke="#8AA0B0" strokeWidth="8" fill="none" strokeLinecap="round"/>
      <ellipse cx="14" cy="64" rx="10" ry="5" fill="#8AA0B0"/>
      <ellipse cx="34" cy="66" rx="10" ry="5" fill="#8AA0B0"/>
    </svg>
  )
}

// Gato 4 — Carey oscuro sentado (esquina inf der)
function CatCarey({ style }) {
  return (
    <svg viewBox="0 0 110 130" style={style} xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="52" cy="95" rx="38" ry="28" fill="#5C3D1E"/>
      <path d="M20,90 Q52,80 84,90 Q84,118 52,123 Q20,118 20,90Z" fill="#5C3D1E"/>
      <ellipse cx="38" cy="98" rx="10" ry="14" fill="#8B5E2A" opacity="0.7"/>
      <ellipse cx="66" cy="92" rx="8" ry="12" fill="#C8A060" opacity="0.5"/>
      <circle cx="52" cy="52" r="26" fill="#5C3D1E"/>
      <ellipse cx="36" cy="58" rx="9" ry="12" fill="#8B5E2A" opacity="0.6"/>
      <ellipse cx="65" cy="46" rx="7" ry="10" fill="#C8A060" opacity="0.4"/>
      <polygon points="32,38 24,18 42,30" fill="#4A3018"/>
      <polygon points="72,38 80,18 62,30" fill="#4A3018"/>
      <polygon points="34,38 26,22 40,32" fill="#C8A0A0" opacity="0.6"/>
      <polygon points="70,38 78,22 64,32" fill="#C8A0A0" opacity="0.6"/>
      <ellipse cx="43" cy="50" rx="5" ry="6" fill="#C9A060"/>
      <ellipse cx="61" cy="50" rx="5" ry="6" fill="#C9A060"/>
      <ellipse cx="43" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <ellipse cx="61" cy="50" rx="2.5" ry="5.5" fill="#1a1a2e"/>
      <circle cx="44" cy="48" r="1.2" fill="white"/>
      <circle cx="62" cy="48" r="1.2" fill="white"/>
      <path d="M49,58 L52,61 L55,58" fill="#D4A0A0"/>
      <line x1="35" y1="58" x2="22" y2="55" stroke="#8B6040" strokeWidth="1" opacity="0.5"/>
      <line x1="35" y1="61" x2="22" y2="61" stroke="#8B6040" strokeWidth="1" opacity="0.5"/>
      <line x1="69" y1="58" x2="82" y2="55" stroke="#8B6040" strokeWidth="1" opacity="0.5"/>
      <line x1="69" y1="61" x2="82" y2="61" stroke="#8B6040" strokeWidth="1" opacity="0.5"/>
      <path d="M85,100 Q105,80 100,58" stroke="#4A3018" strokeWidth="7" fill="none" strokeLinecap="round"/>
      <ellipse cx="35" cy="118" rx="11" ry="6" fill="#4A3018"/>
      <ellipse cx="58" cy="120" rx="11" ry="6" fill="#4A3018"/>
    </svg>
  )
}

export default function CatCorners({ position }) {
  const base = { position: 'absolute', pointerEvents: 'none' }

  if (position === 'top') return (
    <div style={{ position: 'relative', width: '100%', height: 140, overflow: 'visible' }}>
      <CatSiames style={{ ...base, width: 110, top: -10, left: -10, zIndex: 2 }} />
      <CatTabby  style={{ ...base, width: 110, top: -10, right: -10, zIndex: 2, transform: 'scaleX(-1)' }} />
      {/* Flores decorativas top */}
      <div style={{ position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 8, zIndex: 1 }}>
        {['#B8CCD8','#3D6E8A','#C5D8E4','#3D6E8A','#B8CCD8'].map((c, i) => (
          <div key={i} style={{ width: i===2?28:20, height: i===2?28:20, borderRadius: '50%', background: c, opacity: 0.6, marginTop: i===2?0:4 }}/>
        ))}
      </div>
    </div>
  )

  if (position === 'bottom') return (
    <div style={{ position: 'relative', width: '100%', height: 130, overflow: 'visible' }}>
      <CatGris  style={{ ...base, width: 140, bottom: -10, left: -10, zIndex: 2 }} />
      <CatCarey style={{ ...base, width: 110, bottom: -10, right: -10, zIndex: 2 }} />
      <div style={{ position: 'absolute', bottom: 20, left: '50%', transform: 'translateX(-50%)', display: 'flex', gap: 8 }}>
        {['#B8CCD8','#3D6E8A','#C5D8E4','#3D6E8A','#B8CCD8'].map((c, i) => (
          <div key={i} style={{ width: i===2?28:20, height: i===2?28:20, borderRadius: '50%', background: c, opacity: 0.6, marginTop: i===2?0:4 }}/>
        ))}
      </div>
    </div>
  )

  return null
}
