import React from 'react'
import { WEDDING } from '../config'
import CatCorners    from '../components/CatCorners'
import Countdown     from '../components/Countdown'
import AttendanceForm from '../components/AttendanceForm'
import SongForm      from '../components/SongForm'
import PhotoUpload   from '../components/PhotoUpload'
import TipsModal     from '../components/TipsModal'

function GoldDivider() {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, margin: '4px 0' }}>
      <div style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, transparent, var(--gold))' }} />
      <div style={{ color: 'var(--gold)', fontSize: 12 }}>♥</div>
      <div style={{ flex: 1, height: 1, background: 'linear-gradient(90deg, var(--gold), transparent)' }} />
    </div>
  )
}

function Section({ children, style }) {
  return <div style={{ marginBottom: 20, ...style }}>{children}</div>
}

function SectionLabel({ children }) {
  return (
    <p style={{
      fontFamily: "'Lora', serif", fontSize: 10, letterSpacing: 3,
      textTransform: 'uppercase', color: 'var(--blue-mid)', textAlign: 'center',
      marginBottom: 16,
    }}>{children}</p>
  )
}

export default function InvitationPage() {
  const s = {
    page: {
      minHeight: '100vh',
      background: 'var(--cream)',
      maxWidth: 430,
      margin: '0 auto',
      paddingBottom: 40,
      position: 'relative',
    },

    // HERO
    hero: {
      background: 'linear-gradient(180deg, #EEF5FA 0%, #FDFAF5 100%)',
      paddingTop: 10,
      paddingBottom: 30,
      textAlign: 'center',
      position: 'relative',
      overflow: 'visible',
    },
    inviteText: {
      fontFamily: "'Lora', serif",
      fontStyle: 'italic',
      fontSize: 13,
      color: 'var(--text-soft)',
      lineHeight: 1.6,
      padding: '0 40px',
      marginTop: 130,
      marginBottom: 10,
    },
    bodaLabel: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 28,
      color: 'var(--gold)',
      display: 'block',
      marginBottom: 2,
    },
    nombres: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 52,
      color: 'var(--blue-deep)',
      lineHeight: 1.1,
      marginBottom: 8,
      display: 'block',
    },
    specialText: {
      fontFamily: "'Lora', serif",
      fontStyle: 'italic',
      fontSize: 13,
      color: 'var(--text-soft)',
      lineHeight: 1.6,
      padding: '0 40px',
      marginBottom: 20,
    },

    // Foto pareja
    photoWrap: {
      width: 140, height: 140,
      borderRadius: '50%',
      margin: '16px auto',
      border: '4px solid white',
      boxShadow: '0 4px 20px rgba(61,110,138,0.2)',
      overflow: 'hidden',
      background: 'var(--blue-mist)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    },
    photoImg: { width: '100%', height: '100%', objectFit: 'cover' },
    photoPlaceholder: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 14, color: 'var(--blue-deep)',
      textAlign: 'center', padding: '0 10px', lineHeight: 1.4,
    },

    // Fecha card
    fechaCard: {
      background: 'white',
      borderRadius: 16,
      padding: '20px 20px',
      margin: '0 16px',
      boxShadow: '0 2px 20px rgba(61,110,138,0.08)',
      border: '1px solid rgba(197,216,228,0.4)',
      textAlign: 'center',
    },
    fechaRow: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16,
      marginTop: 12,
    },
    fechaDia: {
      fontFamily: "'Lora', serif",
      fontSize: 11, letterSpacing: 2,
      textTransform: 'uppercase',
      color: 'var(--text-soft)',
    },
    fechaNum: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 72, fontWeight: 700,
      color: 'var(--blue-deep)',
      lineHeight: 1,
    },
    fechaHora: {
      fontFamily: "'Lora', serif",
      fontSize: 11, letterSpacing: 2,
      textTransform: 'uppercase',
      color: 'var(--text-soft)',
    },
    fechaMes: {
      fontFamily: "'Lora', serif",
      fontSize: 10, letterSpacing: 3,
      textTransform: 'uppercase',
      color: 'var(--text-soft)',
      marginTop: 4,
    },

    // Location card
    locationCard: {
      background: 'white',
      borderRadius: 16,
      padding: '20px 20px',
      margin: '0 16px',
      boxShadow: '0 2px 20px rgba(61,110,138,0.08)',
      border: '1px solid rgba(197,216,228,0.4)',
    },
    locationTitle: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 24, color: 'var(--blue-deep)', marginBottom: 6,
    },
    locationName: {
      fontFamily: "'Lora', serif",
      fontSize: 14, fontWeight: 600, color: 'var(--text)', marginBottom: 4,
    },
    locationAddr: {
      fontFamily: "'Lora', serif",
      fontStyle: 'italic', fontSize: 13,
      color: 'var(--text-mid)', lineHeight: 1.5, marginBottom: 14,
    },
    mapsBtn: {
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      width: '100%', padding: '12px',
      background: 'var(--blue-deep)', border: 'none', borderRadius: 12,
      fontFamily: "'Lora', serif", fontSize: 14, fontWeight: 600,
      color: 'white', cursor: 'pointer', textDecoration: 'none',
    },

    // Footer
    footer: {
      textAlign: 'center',
      padding: '30px 20px 20px',
      background: 'linear-gradient(180deg, var(--cream) 0%, #EEF5FA 100%)',
      position: 'relative',
      overflow: 'visible',
    },
    footerNombres: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 40, color: 'var(--blue-deep)',
      display: 'block', marginBottom: 4,
    },
    footerSub: {
      fontFamily: "'Dancing Script', cursive",
      fontSize: 22, color: 'var(--gold)',
    },
    contacto: {
      fontFamily: "'Lora', serif",
      fontSize: 11, color: 'var(--text-soft)',
      marginTop: 14,
    },
  }

  return (
    <div style={s.page}>

      {/* HERO */}
      <div style={s.hero}>
        <CatCorners position="top" />

        <p style={s.inviteText}>
          Tenemos el gusto de invitarte en este dia<br />
          tan importante de nuestras vidas
        </p>

        <span style={s.bodaLabel}>Nuestra Boda</span>
        <span style={s.nombres}>Michelle y Jair</span>

        {/* Foto pareja */}
        <div style={s.photoWrap}>
          {WEDDING.fotoPareja
            ? <img src={WEDDING.fotoPareja} alt="Michelle y Jair" style={s.photoImg} />
            : <p style={s.photoPlaceholder}>Foto de los novios</p>
          }
        </div>

        <p style={s.specialText}>
          Este dia tan especial estaremos junto a<br />
          nuestros seres queridos.
        </p>

        <GoldDivider />
      </div>

      {/* FECHA */}
      <Section style={{ padding: '20px 0 0' }}>
        <SectionLabel>Fecha y hora</SectionLabel>
        <div style={s.fechaCard}>
          <div style={s.fechaRow}>
            <span style={s.fechaDia}>SABADO</span>
            <span style={s.fechaNum}>19</span>
            <span style={s.fechaHora}>A LAS 3:00</span>
          </div>
          <p style={s.fechaMes}>DICIEMBRE · 2026</p>
        </div>
      </Section>

      {/* COUNTDOWN */}
      <Section style={{ paddingTop: 20 }}>
        <SectionLabel>Cuenta regresiva</SectionLabel>
        <Countdown />
      </Section>

      {/* UBICACION */}
      <Section style={{ paddingTop: 4 }}>
        <SectionLabel>Ubicacion</SectionLabel>
        <div style={s.locationCard}>
          <h3 style={s.locationTitle}>Como llegar</h3>
          <p style={s.locationName}>{WEDDING.lugarNombre}</p>
          <p style={s.locationAddr}>{WEDDING.lugarDireccion}</p>
          <a href={WEDDING.mapsUrl} target="_blank" rel="noreferrer" style={s.mapsBtn}>
            <span>📍</span>
            <span>Ver en Google Maps</span>
          </a>
        </div>
      </Section>

      {/* CONFIRMACION */}
      <Section style={{ paddingTop: 4 }}>
        <SectionLabel>Confirmacion de asistencia</SectionLabel>
        <AttendanceForm />
      </Section>

      {/* CANCION */}
      <Section style={{ paddingTop: 4 }}>
        <SectionLabel>Sugerencia de cancion</SectionLabel>
        <SongForm />
      </Section>

      {/* FOTOS */}
      <Section style={{ paddingTop: 4 }}>
        <SectionLabel>Galeria de fotos</SectionLabel>
        <PhotoUpload />
      </Section>

      {/* TIPS */}
      <Section style={{ padding: '4px 16px 0' }}>
        <TipsModal />
      </Section>

      {/* FOOTER */}
      <div style={s.footer}>
        <GoldDivider />
        <div style={{ marginTop: 24 }}>
          <span style={s.footerNombres}>Michelle &amp; Jair</span>
          <p style={s.footerSub}>¡Te esperamos!</p>
          <p style={s.contacto}>
            Confirmar al: {WEDDING.telefono1} / {WEDDING.telefono2}
          </p>
        </div>
        <div style={{ marginTop: 20 }}>
          <CatCorners position="bottom" />
        </div>
      </div>

    </div>
  )
}
