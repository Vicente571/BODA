// ═══════════════════════════════════════════════
//  CONFIGURACION DE LA BODA — edita aqui todo
// ═══════════════════════════════════════════════

export const WEDDING = {
  novia:    'Michelle',
  novio:    'Jair',
  fecha:    new Date('2026-12-19T15:00:00'),   // Sab 19 Dic 2026 a las 3:00 PM
  lugarNombre: 'Barda Rincon de Piedra',
  lugarDireccion: 'Colosio, Colonia Vista Alegre, 36679 Irapuato, Gto.',
  mapsUrl: 'https://www.google.com/maps/search/?api=1&query=Colosio+Colonia+Vista+Alegre+36679+Irapuato+Gto',
  telefono1: '462 140 5185',
  telefono2: '462 254 8960',
  fotoPareja: '',   // <-- pega aqui la URL de la foto de los novios
}

// ═══════════════════════════════════════════════
//  GOOGLE SHEETS API
//  1. Crea un Google Sheet nuevo
//  2. Ve a Extensiones → Apps Script
//  3. Pega el codigo del archivo APPS_SCRIPT.gs
//  4. Implementa como App Web (Cualquier persona)
//  5. Pega la URL aqui abajo
// ═══════════════════════════════════════════════
export const API_URL = 'TU_URL_DE_APPS_SCRIPT'

// ═══════════════════════════════════════════════
//  IMGBB — para subir fotos de la boda
//  1. Crea cuenta en imgbb.com
//  2. Ve a api.imgbb.com y copia tu API key
// ═══════════════════════════════════════════════
export const IMGBB_KEY = 'TU_API_KEY_IMGBB'

// ═══════════════════════════════════════════════
//  ADMIN — credenciales del panel
// ═══════════════════════════════════════════════
export const ADMIN_USER = 'admin'
export const ADMIN_PASS = 'boda2026'   // <-- cambia esto
